#include <stdio.h>
#include <stdlib.h>

#ifndef FICHIER
#define FICHIER

void level_to_fichier(char *fichier, int** plateau);
void fichier_to_level(char * fichier, int **plateau);



#endif
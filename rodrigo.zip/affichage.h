#include <stdio.h>
#include <stdlib.h>

#ifndef AFFICHAGE	
#define AFFICHAGE

void affichage(int **plateau, int taille);
void affiche_tab_2D(int **t, int n, int m);



#endif 
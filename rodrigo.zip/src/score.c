#include <stdio.h>
#include <stdlib.h>


int calcule_score(int nb_tours, int temps, int num_niveau){
	if (temps!=0){
		int score=1000*num_niveau-(temps*nb_tours);
		if(score<0){
			return 0;
		}
		return score;
	}
	return 1000*num_niveau;
	
}

void get_best_score(int *tab){
	FILE *f=fopen("./score.txt", "r");
	if (f==NULL){
		exit(-1);
	}

	int a_jeter;

	for(int i=1;i<11;i++){
		fscanf(f, "Map %d : %d\n",&a_jeter,&tab[i-1]);
	}

	fclose(f);
}


void affiche_score(int best_score, int score){
	printf("Score : %d            Best score : %d\n\n",score,best_score );
}

void maj_best_score(int* score_tab, int best_score, int num_niveau){
	FILE *f=fopen("./score.txt", "w");
	if (f==NULL){
		exit(-1);
	}

	score_tab[num_niveau-1]=best_score;

	for(int i=1;i<11;i++){
		fprintf(f, "Map %d : %d\n",i,score_tab[i-1]);
	}

	fclose(f);
}

void fichier_score(){
	FILE *f=fopen("./score.txt", "w");
	if (f==NULL){
		exit(-1);
	}

	int score=0;

	for(int i=1;i<11;i++){
		fprintf(f, "Map %d : %d\n",i,score);
	}

	fclose(f);
}
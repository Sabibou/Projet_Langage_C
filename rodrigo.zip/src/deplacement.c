#include <stdio.h>
#include <stdlib.h>

#include "../inc/affichage.h"
#include "../inc/deplacement.h"


int deplacement_possible(int **plateau, int taille, int x, int y, char direc, int entite){ //x,y coord de lentite dans le tableau
	if (direc=='z'){
		if (x>0){
			if(entite!=2 && (plateau[x-1][y]==2 || plateau[x-1][y]==5)){
				return deplacement_possible(plateau, taille, x-1,y,'z',2);
			}
			else if(plateau[x-1][y]==0 || plateau[x-1][y]==3 ){
				return 1;
			}
		}
	}
	else if (direc=='s'){
		if (x<taille-1){
			if(entite!=2 && (plateau[x+1][y]==2 || plateau[x+1][y]==5) ){
				return deplacement_possible(plateau,taille, x+1,y,'s',2);
			}
			else if(plateau[x+1][y]==0 || plateau[x+1][y]==3 ){
				return 1;
			}
		}
	}
	else if (direc=='d'){
		if (y<taille-1){
			if(entite!=2 && (plateau[x][y+1]==2 || plateau[x][y+1]==5) ){
				return deplacement_possible(plateau,taille, x,y+1,'d',2);
			}
			else if(plateau[x][y+1]==0 || plateau[x][y+1]==3 ){
				return 1;
			}
		}
	}
	else{ //direct=='g'
		if (y>0){
			if(entite!=2 && (plateau[x][y-1]==2 || plateau[x][y-1]==5)){
				return deplacement_possible(plateau,taille,x,y-1,'q',2);
			}
			else if(plateau[x][y-1]==0 || plateau[x][y-1]==3 ){
				return 1;
			}
		}
	}
	return 0;

}

void maj_carte(int ** plateau, int taille, int *x, int *y, int depla_x, int depla_y){
	int val; 

	int ajout_x=0, ajout_y=0;

	if(depla_x<0){ajout_x=-1;}
	else if(depla_x>0){ajout_x=1;}

	if(depla_y<0){ajout_y=-1;}
	else if(depla_y>0){ajout_y=1;}

	plateau[*x][*y]-=1;  //la case où était le perso devient vide
	if(plateau[*(x)+depla_x][*(y)+depla_y]==5){ //cas où la caisse est sur l'objective
		plateau[*(x)+depla_x][*(y)+depla_y]=4;
		plateau[*(x)+depla_x+ajout_x][*(y)+depla_y+ajout_y]=2;
	}
	else if(plateau[*(x)+depla_x][*(y)+depla_y]==3){  //cas où le personnage va sur l'objective
		plateau[*(x)+depla_x][*(y)+depla_y]=4;
	}
	else{
		val=plateau[*(x)+depla_x][*(y)+depla_y];
		plateau[*(x)+depla_x][*(y)+depla_y]=1;
		plateau[*(x)+depla_x+ajout_x][*(y)+depla_y+ajout_y]+=val;	
	}
	*x+=depla_x;	//mise à jour coord perso
	*y+=depla_y;

}

void deplacememt(int direc, int ** plateau, int taille, int *x, int *y){

	if (direc=='z'){
		if(deplacement_possible(plateau, taille, *x, *y, direc, 1)==1){

			maj_carte(plateau, taille, x, y, -1, 0);

		}
	}
	else if (direc=='s'){
		if(deplacement_possible(plateau, taille, *x, *y, direc, 1)==1){

			maj_carte(plateau, taille, x, y, 1, 0);

		}
	}
	else if (direc=='q'){
		if(deplacement_possible(plateau, taille, *x, *y, direc, 1)==1){

			maj_carte(plateau, taille, x, y, 0, -1);
		}
	}
	else if (direc=='d'){
		if(deplacement_possible(plateau, taille, *x, *y, direc, 1)==1){

			maj_carte(plateau, taille, x, y, 0, 1);

		}
	}
	
}


int detect_fin(int **plateau, int taille){
	int nb_indices_restants=0;
	int bloque;
	for(int i=0;i<taille;i++){
		for(int j=0;j<taille;j++){
			if(plateau[i][j]==4 || plateau[i][j]==3){
				nb_indices_restants++;  //on compte le nombre d'indices restants sur la map
			}
			else if (plateau[i][j]==1 ){
				bloque=0;
				bloque+=deplacement_possible(plateau, taille, i, j, 'z', 1);
				bloque+=deplacement_possible(plateau, taille, i, j, 's', 1);
				bloque+=deplacement_possible(plateau, taille, i, j, 'q', 1);
				bloque+=deplacement_possible(plateau, taille, i, j, 'd', 1);
				if (bloque==0){
					return -1;
				}
			}
			else if(plateau[i][j]==2){
				bloque=0;
				bloque+=deplacement_possible(plateau, taille, i, j, 'z', 2);
				bloque+=deplacement_possible(plateau, taille, i, j, 's', 2);
				bloque+=deplacement_possible(plateau, taille, i, j, 'q', 2);
				bloque+=deplacement_possible(plateau, taille, i, j, 'd', 2);
				if (bloque<2){
					return -1;
				}
			}
			
		}
	}
	if(nb_indices_restants==0){return 1;}
	return 0;
}
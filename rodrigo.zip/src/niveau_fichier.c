#include <stdio.h>
#include <stdlib.h>

#include "../inc/niveau_fichier.h"


void save(int** plateau, int niveau, int time, int nb_tours){
	FILE *f=fopen("./maps/save.txt", "w");
	if(f==NULL){
		exit(-1);
	}
	fprintf(f,"%d %d %d  ",niveau, time, nb_tours);
	for(int i=0;i<20;i++){
		for(int j=0;j<20;j++){
			fprintf(f,"%d ",plateau[i][j]);
		}
	}
	fclose(f);
}

void charger(int *num_niveau, int **plateau, int *x, int *y, int charge_save, int *time, int *nb_tours){

	FILE *f;
	if(charge_save==1){
		f=fopen("./maps/save.txt", "r");
		if(f==NULL){
			exit(-1);
		}
		fscanf(f,"%d %d %d  ",num_niveau, time, nb_tours);
	}
	else{
		printf("%d\n", *num_niveau);
		char fichier[30];
		sprintf(fichier, "./maps/map%d.txt", *num_niveau);
		printf("%s\n",fichier );

		f=fopen(fichier, "r");
		if(f==NULL){
			exit(-1);
		}
	}
	for(int i=0;i<20;i++){
		for(int j=0;j<20;j++){
			fscanf(f,"%d ",&plateau[i][j]);
			if(plateau[i][j]==1){
				*x=i;
				*y=j;
			}
		}
	}
	fclose(f);


}

int if_file_exist(char *fichier){
	FILE *f=fopen(fichier,"r");
	if (f==NULL){
		return -1;
	}
	fclose(f);
	return 1;
}
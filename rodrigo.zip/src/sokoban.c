#include <stdio.h>
#include <stdlib.h>
#include <string.h>

#include "../inc/affichage.h"
#include "../inc/deplacement.h"
#include "../inc/niveau_fichier.h"
#include "../inc/timer.h"
#include "../inc/gestion_menu.h"
//-1 : mur, 1 :pers, 2 :caisse, 0 : vide, 3:objectif, 5:caisse sur objectif ,4:perso sur objectif


int main(){
	int **tab=malloc(sizeof(int*)*20);
	if(tab==NULL){
		printf("probleme tab");
	}
	for(int i=0;i<20;i++){
		tab[i]=malloc(sizeof(int)*20);
		if(tab[i]==NULL){
			printf("probleme tab[i]");
			for(int k;k<i;k++){
				free(tab[k]);
			}
			free(tab);
		}

	}
	int game=0;

	while(game==0){
		menu(tab);
	}
	
	for(int i=0;i<20;i++){
		free(tab[i]);
	}
	free(tab);
	return 0;
}
#include <stdio.h>
#include <stdlib.h>
#include <string.h>

#include "../inc/gestion_menu.h"
#include "../inc/timer.h"
#include "../inc/affichage.h"
#include "../inc/deplacement.h"
#include "../inc/niveau_fichier.h"
#include "../inc/score.h"

//fonction affichant le menu et permettant au joueur de choisir ce qu'il veut faire
void menu(int ** plateau, int *score_tab){

	system("clear");
	printf("----------SOKOBAN----------\n\n");
	printf("1. Nouvelle partie\n2. Charger partie\n3. Règles\n4. Quitter le jeu\n");

	int choix;

	do{
		scanf("%d",&choix);
		if(choix == 1){
			lance_niveau(1, plateau,0, score_tab);  //lance le premier niveau
		}
		else if(choix == 2){
			if(if_file_exist("./maps/save.txt")==1){ //si le fichier de sauvegarde existe, on charge
				lance_niveau(0,plateau,1,score_tab);
			}
			else{
				printf("Il n'y a pas de fichier de sauvegarde.\n"); //sinon le joueur doit faire une autre choix
				choix=5;
			}
		}
		else if(choix == 3){  //affiche les règles
			regles();
		}
		else if(choix==4){ //quitte le programme
		}

	}while(choix >4 || choix <1 || choix==3);
}

//focntion permettant de lancer le niveau voulue
void lance_niveau(int num_niveau, int **plateau, int charger_niveau, int *score_tab){

	int x,y;  //variables acceuillants les coord du perso
	int complete=0; //permet de savoir quand arrêter le niveau
	int nb_tours=0;
	int decalage=0;  //lorsqu'on charge une partie permet de savoir combien de secondes s'étaient écoulés
	int score;
	int diff_int; //ici est stocké la différence de temps entre le moment où la partie a commencé et le moment présent
	int input;

	if (charger_niveau==1){  //charge le niveau sauvegarder

		charger(&num_niveau, plateau, &x,&y,1,&decalage,&nb_tours);
	}
	else{
		charger(&num_niveau, plateau, &x,&y,0,&decalage,&nb_tours);
	}


	time_t start=get_time();  //on stocke le moment où on a commencé la partie

	while(complete==0){  
		
		system("clear");

		affiche_timer(start, &diff_int, decalage);  //on affiche le temps

		score=calcule_score(nb_tours,diff_int,num_niveau); //on calcule le score
		affiche_score(score_tab[num_niveau-1], score); //on l'affiche

		affichage(plateau, 20); //on affiche le plateau

		input=getchar(); //on demande au joueur d'agir 
		if(input=='i'){  //le joueur sauvegarde
			save(plateau, num_niveau, diff_int, nb_tours);
		}
		else{ //on appelle la fonction déplacement qui va se charger des déplacements
			deplacememt(input, plateau,20,&x,&y,&nb_tours);
		}

		complete=detect_fin(plateau, 20);  //on vérifie que le niveau n'est pas fini
	}
	//une fois le niveau fini(peut importe le résultat)
	affiche_timer(start, &diff_int, decalage); //on affiche le temps total
	affiche_score(score_tab[num_niveau-1],score); //on affiche le score

	if(score>score_tab[num_niveau-1] && complete==1){  //on vérifie si le joueur a battu le meilleur score
		maj_best_score(score_tab,score,num_niveau);
		printf("Nouveau meilleur score !!\n\n");
	}
	fin_niveau(complete,num_niveau,plateau,score_tab);

}

//fonction gérant la transition entre les niveaux
void fin_niveau(int fin,int num_niveau, int **plateau, int *score_tab){
	int choix_fin=0;
	do{
		if(fin==1){  //cas où le joueur a gagné
			printf("----------Vous avez terminé le niveau----------\n\n");
			printf("Que souhaitez-vous faire ? :\n");
			printf("1. Passer au niveau suivant\n2. Retourner au menu\n");
			scanf("%d",&choix_fin);
			if(choix_fin==1){
				lance_niveau(num_niveau+1, plateau,0,score_tab); //on lance le niveau suivant 
			}
		}
		else if(fin==-1){ //cas où le joueur a perdu 
			printf("----------Vous avez perdu----------\n\n");
			printf("Que souhaitez-vous faire ? :\n");
			printf("1. Retenter le niveau\n2. Retourner au menu\n");
			scanf("%d",&choix_fin);
			if(choix_fin==1){
				lance_niveau(num_niveau, plateau,0,score_tab); //on relance le même niveau
			}
		}

		if(choix_fin==2){
			menu(plateau, score_tab);  //on accède au menu
		}
	}while(choix_fin<1 || choix_fin>2);
}

void regles(){

	system("clear");
	printf("------------------------Bienvenu au jeu Sokoban-------------------------\n\n");
	printf("Le but est de placer l'ensemble des caisses, représentées par c, sur les indices I.\n\n");
	printf("Pour cela, bougez votre personnage, signifié par l'icône P, à l'aide des touches Z,Q,S,D permettant respectivement d'aller en haut, à gauche, en bas et à droite.\n\n");
	printf("Vous allez être confronté à 10 niveaux allant dans un ordre croissant de difficulté.\n\n");
	printf("Les niveaux seront chronométrés. Essayez d'en venir à bout rapidement et avec le moins de coup possible pour avoir le meilleur score possible.\n\n");
	printf("Vous pouvez retrouver vos meilleurs scores dans le fichier score.txt.\n\n");
	printf("Vous pouvez sauvegarder à tout moment en appuyant sur la touche i puis entrée.\n\n");
	printf("1. Nouvelle partie\n2. Charger partie\n3. Règles\n4. Quitter le jeu\n");


}
#include <stdio.h>
#include <stdlib.h>
#include <string.h>

#include "../inc/gestion_menu.h"
#include "../inc/timer.h"
#include "../inc/affichage.h"
#include "../inc/deplacement.h"
#include "../inc/niveau_fichier.h"

void menu(int ** plateau){

	system("clear");
	printf("----------SOKOBAN----------\n\n");
	printf("1. Nouvelle partie\n2. Charger partie\n3. Règles\n4. Quitter le jeu\n");

	int choix;

	do{
		scanf("%d",&choix);
		if(choix == 1){
			lance_niveau(1, plateau,0);
		}
		else if(choix == 2){
			if(if_file_exist("./maps/save.txt")==1){
				lance_niveau(0,plateau,1);
			}
			else{
				printf("Il n'y a pas de fichier de sauvegarde.\n");
				choix=5;
			}
		}
		else if(choix == 3){
			regles();
		}
		else if(choix==4){
			exit(0);
		}
	}while(choix >4 || choix <1);
}

void lance_niveau(int num_niveau, int **plateau, int charger_niveau){

	int x,y;

	if (charger_niveau==1){

		num_niveau=charger(num_niveau, plateau, &x,&y,1);
	}
	else{
		num_niveau=charger(num_niveau, plateau, &x,&y,0);
	}

	int complete=0;
	int input;
	time_t start=get_time();

	while(complete==0){
		
		system("clear");

		affiche_timer(start);
		affichage(plateau, 20);

		input=getchar();
		if(input=='i'){
			save(plateau, num_niveau);
		}
		else{
			deplacememt(input, plateau,20,&x,&y);
		}

		complete=detect_fin(plateau, 20);
	}
	fin_niveau(complete,num_niveau,plateau);

}

void fin_niveau(int fin,int num_niveau, int **plateau){
	int choix_fin=0;
	do{
		if(fin==1){
			printf("----------Vous avez terminé le niveau----------\n\n");
			printf("Que souhaitez-vous faire ? :\n");
			printf("1. Passer au niveau suivant\n2. Retourner au menu\n");
			scanf("%d",&choix_fin);
			if(choix_fin==1){
				lance_niveau(num_niveau+1, plateau,0);
			}
		}
		else if(fin==-1){
			printf("----------Vous avez perdu----------\n\n");
			printf("Que souhaitez-vous faire ? :\n");
			printf("1. Retenter le niveau\n2. Retourner au menu\n");
			scanf("%d",&choix_fin);
			if(choix_fin==1){
				lance_niveau(num_niveau, plateau,0);
			}
		}

		if(choix_fin==2){
			menu(plateau);
		}
	}while(choix_fin<1 || choix_fin>2);
}

void regles(){
	printf("Bienvenu au jeu Sokoban.\n Le but est de placer l'ensemble des caisses, représentées par C, sur les indices I.\n Pour cela, bougez votre personnage, signifié par l'icône P, à l'aide des touches Z,Q,S,D permettant respectivement d'aller en haut, à gauche, en bas et à droite.\n Vous allez être confrontés à 10 niveaux allant dans l'ordre croissante de difficulté. Vous pouvez sauvegarder à tout moment en appuyant sur la touche s puis entrée.");
}
#include <stdio.h>
#include <stdlib.h>

#ifndef FICHIER
#define FICHIER

void save(int** plateau, int niveau);
int charger(int num_niveau, int **plateau, int *x, int *y, int charge_save);
int if_file_exist(char *fichier);


#endif
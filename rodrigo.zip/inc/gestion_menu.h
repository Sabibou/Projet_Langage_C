#include <stdio.h>
#include <stdlib.h>

#ifndef MENU
#define MENU

void menu(int ** plateau);
void lance_niveau(int num_niveau, int ** plateau,int charger_niveau);
void fin_niveau(int fin,int num_niveau, int **plateau);
void regles();




#endif 
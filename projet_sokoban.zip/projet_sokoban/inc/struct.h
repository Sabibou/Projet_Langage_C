#ifndef STRUCT_H_
#define STRUCT_H_

#include "main.h"

struct pos {
	int x;
	int y;
};

typedef struct pos pos_t;

#endif

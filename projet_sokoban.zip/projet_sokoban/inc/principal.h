#ifndef PRINCIPAL_H_
#define PRINCIPAL_H_

#include "main.h"

char **game_key_event(char **, pos_t);
char **game_key_event_end(char **, pos_t, int);

#endif

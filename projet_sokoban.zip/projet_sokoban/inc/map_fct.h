#ifndef MAP_FUNCTIONS
#define MAP_FUNCTIONS

#include "main.h"

int find_max_line(char *);
char **init_map(char *, int);
void display_map(char **, int);

#endif

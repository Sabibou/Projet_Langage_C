#ifndef CONTROL_H_
#define CONTROL_H_

#include "main.h"

void check_victory(WINDOW *, char **, pos_t *, int);
void check_defeat(WINDOW *, char **, int);
int cant_move_box(char **, int, int);
void close_win(WINDOW *, char *, int, int);

#endif

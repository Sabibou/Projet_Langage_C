#ifndef OBJECTIVE_H_
#define OBJECTIVE_H_

#include "main.h"

int find_nbrI(char **, int);
pos_t *init_all_posI(char **, int);
char **display_lost_posI(char **, pos_t *, int);

#endif

#include "main.h"

void check_victory(WINDOW *win, char **map, pos_t *posI, int nbrI)
{
	int vic = 1;

	for (int i = 0; i < nbrI; i++) {
		if (map[posI[i].y][posI[i].x] != 'C')
			vic = 0;
	}
	if (vic == 1)
		close_win(win, "VOUS AVEZ GAIGNE :) :)", 5, 0);
}

void check_defeat(WINDOW *win, char **map, int max_line)
{
	int j = 0;
	int i = 0;
	int nbrBox = 0;
	int nbrFail = 0;

	for (j = 0; j < max_line; j++)
		for (i = 0; map[j][i]; i++)
			if (map[j][i] == 'C') {
				nbrBox++;
				if (cant_move_box(map, j, i) == 1)
					nbrFail++;
			}
	if (nbrFail == nbrBox)
		close_win(win, "VOUS AVEZ PERDU !", 5, 1);
}

int cant_move_box(char **map, int j, int i)
{
	if (   (map[j - 1][i] == '#' && map[j][i - 1] == '#')
	    || (map[j - 1][i] == '#' && map[j][i + 1] == '#')
	    || (map[j + 1][i] == '#' && map[j][i - 1] == '#')
	    || (map[j + 1][i] == '#' && map[j][i + 1] == '#'))
		return (1);
	return (0);
}

void close_win(WINDOW *win, char *str, int len, int status)
{
	clear();
	mvprintw(getmaxy(win) / 2, getmaxx(win) / 2 - len, "%s", str);
	getch();
	refresh();
	endwin();
	exit(status);
}

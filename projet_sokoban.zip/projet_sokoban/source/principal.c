#include "main.h"

char **game_key_event(char **map, pos_t posP)
{
	int ch = getch();

	switch (ch) {
	case KEY_DOWN:
		map = move_player(map, posP, posP.y + 1, posP.x);
		map = boxes_conditions(map, posP, posP.y + 1, posP.x);
		break;
	case KEY_UP:
		map = move_player(map, posP, posP.y - 1, posP.x);
		map = boxes_conditions(map, posP, posP.y - 1, posP.x);
		break;
	case 32:
		map = init_all("map", 7);
		break;
	default:
		map = game_key_event_end(map, posP, ch);
		break;
	}
	return (map);
}

char **game_key_event_end(char **map, pos_t posP, int ch)
{
	switch (ch) {
	case KEY_LEFT:
		map = move_player(map, posP, posP.y, posP.x - 1);
		map = boxes_conditions(map, posP, posP.y, posP.x - 1);
		break;
	case KEY_RIGHT:
		map = move_player(map, posP, posP.y, posP.x + 1);
		map = boxes_conditions(map, posP, posP.y, posP.x + 1);
		break;
	}
	return (map);
}

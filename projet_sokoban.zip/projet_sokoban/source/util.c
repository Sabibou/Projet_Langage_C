#include "main.h"

void my_putchar(char c)
{
        write(1, &c, 1);
}

void my_putstr(char *str)
{
        for (int i = 0; str[i]; i++)
                my_putchar(str[i]);
}

void help(int ac, char **av)
{
	if (ac > 1 && av[1][0] == '-' && av[1][1] == 'o') {
		my_putstr("\n\n[USAGE]\n");
		my_putstr("			  Pour démarrer le jeu écrivez au console: \n");
		my_putstr("			  './sokoban map' en ajoutant le niveau preféré par ex:\n");
		my_putstr("			  Pour niveau 1: './sokoban map/map.lvl1'\n");
		my_putstr("			  niveau 2: './sokoban map/map.lvl2'\n");
		my_putstr("			  En total on a 10 niveaux\n");
		my_putstr("\n\n[DESCRIPTION]\n");
		my_putstr("                 Dans le fichier map, vous allez trouver toutes les cartes possibles du jeu dont chacune des cartes a une niveau de difficulté différente (1-10) \n");
		my_putstr("\nLe caractère:\n");
		my_putstr(" 		      '#' représente les murs\n");
		my_putstr(" 		      'P' représente le personnage\n");
		my_putstr(" 		      'C' représente une caisse\n");
		my_putstr(" 		      'I' représente un point d'intérêt\n");

		exit(84);
	}
}

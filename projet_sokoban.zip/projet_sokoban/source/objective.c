#include "main.h"

int find_nbrI(char **map, int max_line)
{
	int j;
	int i;
	int nbrI = 0;

	for (j = 0; j < max_line; j++)
		for (i = 0; map[j][i]; i++)
			if (map[j][i] == 'I')
				nbrI++;
	return (nbrI);
}

pos_t *init_all_posI(char **map, int max_line)
{
	pos_t *posI;
	int nbrI = 0;
	int i = 0;
	int j = 0;

	for (j = 0; j < max_line; j++)
		for (i = 0; map[j][i]; i++)
			if (map[j][i] == 'I')
				nbrI++;
	posI = malloc(nbrI);
	nbrI = 0;
	for (j = 0; j < max_line; j++)
		for (i = 0; map[j][i]; i++)
			if (map[j][i] == 'I') {
				posI[nbrI].x = i;
				posI[nbrI].y = j;
				nbrI++;
			}
	return (posI);
}

char **display_lost_posI(char **map, pos_t *posI, int nbrI)
{
	for (int i = 0; i < nbrI; i++)
		if (map[posI[i].y][posI[i].x] != 'P'
		    && map[posI[i].y][posI[i].x] != 'C')
			map[posI[i].y][posI[i].x] = 'I';
	return (map);
}

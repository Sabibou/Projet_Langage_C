#include "main.h"

void error_win_size(WINDOW *win, char **map, int max_line)
{
	int max_column = 0;

	for (int i = 0; map[0][i]; i++)
		max_column++;
	if (max_line > getmaxy(win) || max_column > getmaxx(win)) {
		mvprintw(getmaxy(win) / 2,
			 (getmaxx(win) / 2) - 10, "Rezise your window !");
		getch();
		refresh();
		endwin();
		exit(84);
	}
}

void error_map(char **map, int max_line)
{
	int i;
	int nbrC = 0;
	int nbrI = 0;
	int nbrP = 0;

	for (int j = 0; j < max_line; j++)
		for (i = 0; map[j][i]; i++)
			switch (map[j][i]) {
			case 'C':
				nbrC++;
				break;
			case 'I':
				nbrI++;
				break;
			case 'P':
				nbrP++;
				break;
			}
	if (error_composant(nbrC, nbrI, nbrP) == 1)
		exit(84);
}

int error_composant(int nbrC, int nbrI, int nbrP)
{
	if (nbrC == 0 || nbrI == 0 || nbrC < nbrI || nbrC > nbrI || nbrP > 1 || nbrP == 0)
		return (1);
	else
		return (0);
}

# COMPILATION DE JEU

1 : Téléchargez le dossier **projet_sokoban**

2 : Compilez le jeu en écrivant au terminal **make**

3 : En plus exécutez la commande suivante **./sokoban -o**
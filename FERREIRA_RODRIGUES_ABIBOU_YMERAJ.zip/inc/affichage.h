#include <stdio.h>
#include <stdlib.h>

#ifndef AFFICHAGE	
#define AFFICHAGE

void affichage(int **plateau, int taille);
void affiche_score(int best_score, int score);



#endif 